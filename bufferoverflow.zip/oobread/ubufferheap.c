#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <inttypes.h>

int read_int(const char* message)
{
    char s[256], *p = NULL;

    printf("%s", message);
    while (fgets(s, sizeof(s), stdin))
    {
        int index = (int)strtol(s, &p, 10);
        if (p == s || *p != '\n')
        {
            printf("%s", message);
        }
        else
        {
            return index;
        }
    }

    return 0;
}

int main()
{
    uint8_t* nonsensitive;
    uint8_t* sensitive;

    nonsensitive = (uint8_t*)malloc(50 * sizeof(uint8_t));
    sensitive = (uint8_t*)malloc(50 * sizeof(uint8_t));

    /* Fill in buffers */
    for (int i = 0; i != 50; ++i)
    {
        nonsensitive[i] = i;
        sensitive[i] = 100 + i;
    }

    printf("Address of sensitive is: %p\n", sensitive);
    printf("Address of nonsensitive is: %p\n", nonsensitive);
    printf("Difference in addresses: %td\n",
        nonsensitive - sensitive);

    int start = read_int("What index do you want to get from: ");
    int end = read_int("What index do you want to get to: ");

    for (int index = start; index != end; ++index)
    {
        printf("Data at %*d [%p]: %"PRIu8"\n",
            4, index,
            &(nonsensitive[index]),
            nonsensitive[index]);
    }

    return 0;
}
