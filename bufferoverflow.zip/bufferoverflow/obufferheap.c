#include <stdio.h>
#include <stdlib.h>

int main()
{
    char* command;
    char* name;
    command = (char*)malloc(128 * sizeof(char));
    name = (char*)malloc(10 * sizeof(char));
    printf("Address of name is: %p\n", name);
    printf("Address of command is: %p\n", command);
    printf("Difference in addresses: %td\n", name - command);
    printf("Enter you name: \n");
    gets(name);
    printf("Hello %s\n", name);
    system(command);

    return 0;
}
