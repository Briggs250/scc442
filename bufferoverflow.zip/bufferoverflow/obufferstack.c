#include <stdio.h>
#include <stdlib.h>

int main()
{
    char command[128];
    char name[10];
    printf("Address of name is: %p\n", name);
    printf("Address of command is: %p\n", command);
    printf("Difference in addresses: %td\n", name - command);
    printf("Enter you name: \n");
    gets(name);
    printf("Hello %s\n", name);
    system(command);

    return 0;
}
